package com.capgemini.paytm.repo;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.Entity;
import com.capgemini.paytm.beans.Customer;
import com.capgemini.paytm.beans.Transaction;

import com.capgemini.paytm.exception.InvalidInputException;
import com.capgemini.paytm.util.JPAUtil;

public class WalletRepoImpl implements WalletRepo{

	JPAUtil jpautil=new JPAUtil();
	private EntityManager entityManager;
	
	public WalletRepoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	@Override
	public boolean save(Customer customer) {
		beginTransaction();
		entityManager.persist(customer);
		commitTransaction();
		return true;
	}

	@Override
	public Customer findOne(String mobileNo) {		
		Customer customer=new Customer();		
		customer=entityManager.find(Customer.class, mobileNo);
		if(customer!=null)
			return customer;
		else
			throw new InvalidInputException("Account does not exist!");
	}
	@Override
	public Customer Update(String mobileNo, Customer customer)
	{	
		customer=findOne(mobileNo);		
		if(customer==null)
			throw new InvalidInputException("No account found!");
		else
		{
			beginTransaction();
			entityManager.merge(customer);
			commitTransaction();;
			return customer;
		}
	}
	@Override
	public void saveTransaction(Transaction trans) {
		beginTransaction();
		entityManager.persist(trans);
		commitTransaction();
		
	
	}
	@Override
	public List<Transaction> selectTransaction(String mobileNo) {
		String query="SELECT t FROM Transaction t WHERE t.mobileNo LIKE :mobileNo";
		TypedQuery<Transaction> q=entityManager.createQuery(query,Transaction.class);
		q.setParameter("mobileNo", "%"+mobileNo+"%");
		List<Transaction> list=q.getResultList();		
		return list;		
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	
}
