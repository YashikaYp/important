package com.capgemini.paytm.beans;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="NewTransaction")
public class Transaction {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int tid;
	private String mobileNo;
	private String transaction_type,transaction_status;
	private BigDecimal transaction_amt;
	private String transaction_date;
	
	public Transaction(String mobileNo, String transaction_type, String transaction_status, BigDecimal transaction_amt,
			String date) {
		super();
		this.mobileNo = mobileNo;
		this.transaction_type = transaction_type;
		this.transaction_status = transaction_status;
		this.transaction_amt = transaction_amt;
		this.transaction_date = date;
	}
	public Transaction() {
		// TODO Auto-generated constructor stub
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public String getTransaction_status() {
		return transaction_status;
	}
	public void setTransaction_status(String transaction_status) {
		this.transaction_status = transaction_status;
	}
	public BigDecimal getTransaction_amt() {
		return transaction_amt;
	}
	public void setTransaction_amt(BigDecimal transaction_amt) {
		this.transaction_amt = transaction_amt;
	}
	public String getDate() {
		return transaction_date;
	}
	public void setDate(String date) {
		this.transaction_date = date;
	}
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}
	@Override
	public String toString() {
		return "Transaction [tid=" + tid + ", mobileNo=" + mobileNo + ", transaction_type=" + transaction_type
				+ ", transaction_status=" + transaction_status + ", transaction_amt=" + transaction_amt
				+ ", transaction_date=" + transaction_date + "]";
	}
	
}
