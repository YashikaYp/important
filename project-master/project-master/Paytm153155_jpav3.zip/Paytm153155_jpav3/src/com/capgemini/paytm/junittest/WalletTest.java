package com.capgemini.paytm.junittest;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.paytm.beans.Customer;
import com.capgemini.paytm.beans.Transaction;
import com.capgemini.paytm.beans.Wallet;
import com.capgemini.paytm.exception.InvalidInputException;
import com.capgemini.paytm.repo.WalletRepo;
import com.capgemini.paytm.repo.WalletRepoImpl;
import com.capgemini.paytm.service.WalletService;
import com.capgemini.paytm.service.WalletServiceImpl;

import static org.junit.Assert.*;

public class WalletTest {

	WalletService service = new WalletServiceImpl();
	Customer cust1, cust2, cust3;
	WalletRepo repo=new WalletRepoImpl();
	private EntityManager entityManager;
	@Before
	public void initData() {		
		
		service.createAccount("Kalyani", "9900112212", new BigDecimal(9000));		
		service.createAccount("Joey","9922493800", new BigDecimal(6000));
		service.createAccount("Sejal", "9876543210",new BigDecimal(7000));
		
	}
	//--------TestCreateAccount()
	@Test(expected=InvalidInputException.class)
	public void testCreateAccount()
	{
		service.createAccount("", "", new BigDecimal(7000));
	}
	
}
